package com.cg.hms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hms.bean.AdminBean;
import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.EmployeeBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
import com.cg.hms.service.IHotelService;

@Controller
public class HotelController {
	@Autowired
	private IHotelService hserv;
	/*********************************************************************************************************************************************
	 *                                                HOTEL MANAGEMENT SYSTEM HOME PAGE                                                   *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="home")
	public String getHome(Model m)
	{
		return "home/home";
	}
	@RequestMapping(value="adminmainscreen")
	public String getNavigation(Model m)
	{
		return "admin/adminmainscreen";
	}
	
	
	/*********************************************************************************************************************************************
	 *                                                     ADMIN LOGIN PAGE                                                                      *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="admin",method = RequestMethod.POST)
	public String getadminloginPage(Model m)
	{
		return "admin/adminlogin";
	}


	@RequestMapping(value="adminForm",method = RequestMethod.POST)
	public String submit(Model model, @ModelAttribute("loginBean") AdminBean loginBean) {
		if (loginBean != null && loginBean.getUserName() != null & loginBean.getPassword() != null) 
		{
			if (loginBean.getUserName().equals("admin") && loginBean.getPassword().equals("admin")) 
			{
				model.addAttribute("msg", loginBean.getUserName());
				return "admin/adminmainscreen";
			}
			else 
			{
				model.addAttribute("error", "Invalid Details");
				return "admin/adminlogin";
			}
		} 
		else 
		{
			model.addAttribute("error", "Please enter Details");
			return "admin/adminlogin";
		}
	}
	/*********************************************************************************************************************************************
	 *                                                           ADMIN FUNCTIONALITY                                                             *
	 *********************************************************************************************************************************************/
	/*********************************************************************************************************************************************
	 *                                                           PERFORM HOTEL MANAGEMENT                                                        *
	 *********************************************************************************************************************************************/

	@RequestMapping(value="hotelmanagement")                                       
	public String performHotelManagement(Model m)
	{
		return "admin/adminhm";

	}
	/*********************************************************************************************************************************************
	 *                                                           *ADD HOTEL*                                                                     *
	 *********************************************************************************************************************************************/

	@RequestMapping(value="addhotel")                                                           // Add Hotel
	public String addHotel(Model m,@ModelAttribute("hotelObj") HotelBean hotel )
	{
		return "admin/addhotel";

	}
	@RequestMapping(value="performaddhotel",method=RequestMethod.POST)
	public  String storehotel(Model m,@ModelAttribute("hotelObj") HotelBean hotelbean){
		String target=null;
		int  hotelId=hserv.addHotelServ(hotelbean);
		System.out.println(hotelId);
		m.addAttribute("id", hotelId);

		if( hotelId > 0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", hotelId);
			target="admin/success";
		}
		else{
			target="admin/addhotel";
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                           *DELETE  HOTEL*                                                                 *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="deletehotel")                                                          
	public String deleteHotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotel)
	{
		return "admin/deletehotel";

	}
	@RequestMapping(value="deletehotelbyid",method=RequestMethod.POST)
	public  String deletehotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotelbean)
	{
		String target=null;
		int deletehotelid = hotelbean.getHotelid();
		int result;
		result=hserv.deleteHotelById(deletehotelid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deletehotelid);
			target="admin/deletesuccess";

		}
		else
		{
			target="home/home";
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                           *UPDATE  HOTEL*                                                                 *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="updatehotel",method=RequestMethod.POST)                                                          
	public String searchHotelById(Model m,@ModelAttribute("updatehotelObj")HotelBean hotelbean)
	{
		HotelBean Obj = new HotelBean();
		m.addAttribute("updatehotelObj", Obj);
		return "admin/updatehotel";

	}
	@RequestMapping(value="updatehotelbyid",method=RequestMethod.POST)
	public ModelAndView SelectsearchHotel(Model m ,@ModelAttribute("updatehotelObj") HotelBean hotelbean)
	{
		int id = hotelbean.getHotelid();
		System.out.println(id);
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.searchHotelById(id);
		mv.setViewName("admin/updatehotelbyid");
		System.out.println(hotelbean);
		mv.addObject("data", hotellist);
		return mv;
	}
	@RequestMapping(value="updateDetails",method=RequestMethod.POST)                                                         
	public String updateHotel(Model m,@ModelAttribute("updatehotelObj") HotelBean hotelBean,@RequestParam("id") int id)
	{

		hotelBean.setHotelid(id);
		m.addAttribute("hotelBean",hotelBean);
		hserv.updateHotelDetails(hotelBean);
		String msg="Update Successfully";

		return "admin/updatesuccess";

	}
	

	/*********************************************************************************************************************************************
	 *                                                           PERFORM ROOM MANAGEMNET                                                         *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="roommanagement")                                        
	public String performRoomManagement(Model m)
	{
		return "admin/adminrm";

	}
	/*********************************************************************************************************************************************
	 *                                                           *ADD  ROOM*                                                                     *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="addroom")															
	public String addRoom(Model m,@ModelAttribute("roomObj") RoomBean roombean)
	{
		return "admin/addroom";
	}
	@RequestMapping(value="performaddroom",method=RequestMethod.POST)
	public  String storeroom(Model m,@ModelAttribute("roomObj") RoomBean roombean){
		String target=null;
		int  roomId=hserv.addRoomServ(roombean);
		if( roomId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", roomId);
			target="admin/roomsuccess";
		}
		else{
			target="admin/addroom";
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                           *DELETE  ROOM*                                                                   *
	 **********************************************************************************************************************************************/

	@RequestMapping(value="deleteroom")															//Delete Room
	public String deleteRoom(Model m,@ModelAttribute("deleteroomObj") RoomBean roombean)
	{
		return "admin/deleteroom";

	}

	@RequestMapping(value="deleteroombyid",method=RequestMethod.POST)
	public  String deleteroom(Model m,@ModelAttribute("deleteroomObj") RoomBean roombean)
	{
		String target=null;
		int deleteroomid = roombean.getRoomid();
		int result;
		result=hserv.deleteroomById(deleteroomid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deleteroomid);
			target="admin/deletesuccess";
		}
		else
		{
			target="home/home";
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                           *UPDATE  ROOM*                                                                   *
	 **********************************************************************************************************************************************/
	
	
	@RequestMapping(value="updateroom",method=RequestMethod.POST)                                                          
	public String searchRoomById(Model m,@ModelAttribute("updateroomObj")HotelBean hotelbean)
	{
		RoomBean Obj = new RoomBean();
		m.addAttribute("updateroomObj", Obj);
		return "admin/updateroom";

	}
	@RequestMapping(value="updateroombyid",method=RequestMethod.POST)
	public ModelAndView SelectsearchRoom(Model m ,@ModelAttribute("updateroomObj") RoomBean roombean)
	{
		int id = roombean.getRoomid();
		System.out.println(id);
		ModelAndView mv=new ModelAndView();
		ArrayList<RoomBean> roomlist=hserv.searchRoomById(id);
		mv.setViewName("admin/updateroombyid");
		System.out.println(roombean);
		mv.addObject("data", roomlist);
		return mv;
	}
	@RequestMapping(value="updateroomDetails",method=RequestMethod.POST)                                                         
	public String updateRoom(Model m,@ModelAttribute("updateroomObj") RoomBean roomBean,@RequestParam("id") int id)
	{

		roomBean.setRoomid(id);
		m.addAttribute("roomBean",roomBean);
		hserv.updateRoomDetails(roomBean);
		String msg="Update Successfully";

		return "admin/updateroomsuccess";
	}
	
	/*********************************************************************************************************************************************
	 *                                                           *GENERATE REPORT*                                                                   *
	 **********************************************************************************************************************************************/
	@RequestMapping(value="report")
	public String generateReport(Model m)
	{
		return "admin/adminreport";

	}

	/*********************************************************************************************************************************************
	 *                                               VIEW LIST OF ALL HOTELS                                                                     *
	 *********************************************************************************************************************************************/


	@RequestMapping(value="viewallhotels",method=RequestMethod.POST)
	public ModelAndView viewAll(){
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.getAllHotels();
		mv.setViewName("admin/viewallhotels");
		mv.addObject("data", hotellist);
		return mv;
	}
	/*********************************************************************************************************************************************
	 *                                                  VIEW BOOKINGS OF SPECIFIC HOTEL METHOD                                                     *
	 *********************************************************************************************************************************************/

	/*viewspecific
	 * NEED TO COMPLETE
	 */
	
	@RequestMapping(value="viewspecific",method = RequestMethod.POST)     
	public String SpecificHotel(Model m)
	{
		BookingDetailsBean Obj = new BookingDetailsBean();
		m.addAttribute("hotelObj", Obj);
		return "admin/viewspecific";

	}
	@RequestMapping(value="viewspecificbyid",method=RequestMethod.POST)
	public ModelAndView viewHotels(Model m ,@ModelAttribute("hotelObj") BookingDetailsBean beanobj)
	{
		int hotel = beanobj.getHotelid();
		ModelAndView mv=new ModelAndView();
		ArrayList<BookingDetailsBean> hotellist=hserv.viewBookingDetails(hotel);
		mv.setViewName("admin/viewspecificbyid");
		mv.addObject("data", hotellist);
		return mv;
	}
	/*********************************************************************************************************************************************
	 *                                                  VIEW BOOKINGS OF SPECIFIC DATE                                                            *
	 *********************************************************************************************************************************************/
	
	/*viewspecificdate
	 *NEED TO COMPLETE 
	 */

	@RequestMapping(value="viewspecificdate",method = RequestMethod.POST)     
	public String SelectDate(Model m)
	{
		BookingDetailsBean Obj = new BookingDetailsBean();
		m.addAttribute("searchbydateObj", Obj);
		return "admin/viewspecificDate";

	}
	@RequestMapping(value="viewspecificdatebyid",method=RequestMethod.POST)
	public ModelAndView SpecificDate(Model m ,@ModelAttribute("searchbydateObj") BookingDetailsBean beanobj)
	{
		String bookdate = beanobj.getBookedFrom();
		ModelAndView mv=new ModelAndView();
		ArrayList<BookingDetailsBean> hotellist=hserv.viewBookingByDate(bookdate);
		mv.setViewName("admin/viewspecificbydate");
		mv.addObject("data", hotellist);
		return mv;
	}
	 /*********************************************************************************************************************************************
		 *                                                  VIEW ALL GUEST LIST                                                          *
	 *********************************************************************************************************************************************/
	 /*guestlist*/
	
	@RequestMapping(value="viewguestlist",method = RequestMethod.POST)     
	public String ViewGuestList(Model m)
	{
		BookingDetailsBean Obj = new BookingDetailsBean();
		m.addAttribute("guestlistObj", Obj);
		return "admin/guestlist";

	}
	@RequestMapping(value="guestlist",method=RequestMethod.POST)
	public ModelAndView GuestList(Model m ,@ModelAttribute("guestlistObj") BookingDetailsBean beanobj)
	{
		int Hotelid = beanobj.getHotelid();
		ModelAndView mv=new ModelAndView();
		ArrayList<UserBean> userlist=hserv.viewGuestList(Hotelid);
		mv.setViewName("admin/viewguestlist");
		mv.addObject("data", userlist);
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	/*********************************************************************************************************************************************
	 *                                                            USER PART                                                                      *
	 *********************************************************************************************************************************************/
	/*********************************************************************************************************************************************
	 *                                                           USER REGISTRATION                                                               *
	 *********************************************************************************************************************************************/

	@RequestMapping("reg")
	public String getregistration(Model m)
	{
		m.addAttribute("regObj", new  UserBean());
		return "user/UserRegistration";
	}

	@RequestMapping(value="register",method=RequestMethod.POST)
	public  String storeRechargeInfo(Model m,@ModelAttribute("regObj") UserBean u){
		String target=null;

		int  userId=hserv.addUserDetails(u);
		if( userId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", userId);
			target="user/success";
		}
		else{
			target="user/UserRegistration";
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                           USER LOGIN                                                               *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="user",method = RequestMethod.POST)								
	public String user(Model m,@ModelAttribute("userBean") UserBean userbean)
	{
		return "user/userlogin";
	}

	@RequestMapping(value="Userform",method = RequestMethod.POST)
	public String submit3(Model model, @ModelAttribute("userBean") UserBean userbean, HttpSession session ) {
		String target=null;
		model.addAttribute(userbean);
		
		model.addAttribute("user",userbean.getUserName());
		model.addAttribute("pass",userbean.getPassword());

		boolean val=hserv.login(userbean.getUserName(),userbean.getPassword(),userbean);
		session.setAttribute("id", userbean.getUserName());
		
		if(val)
		{
			
			target="user/usermainscreen";
		}
		else
		{
			target="user/userlogin";
			model.addAttribute("status","Login Successfull");
		}
		return target;
	}
	/*********************************************************************************************************************************************
	 *                                                          SEARCH HOTEL  AND  BOOKHOTEL                                                        *
	 *********************************************************************************************************************************************/

	@RequestMapping(value="searchhotel",method = RequestMethod.POST)     
	public String searchHotel(Model m)
	{
		HotelBean Obj = new HotelBean();
		m.addAttribute("locObj", Obj);
		return "user/location";

	}
	@RequestMapping(value="locationhotel",method=RequestMethod.POST)
	public ModelAndView SelectHotel(Model m ,@ModelAttribute("locObj") HotelBean hotelbeanobj)
	{
		String location = hotelbeanobj.getCity();
		System.out.println("Location "+location);
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.selecthotel(location);
		mv.setViewName("user/searchhotel");
		mv.addObject("data", hotellist);
		return mv;
	}
	@RequestMapping(value="displayroom",method = RequestMethod.POST)								
	public String bookroom(Model m )
	{
		RoomBean roombeanobj = new RoomBean();
		m.addAttribute("idObj", roombeanobj);
		return "user/bookroom";
	}
	@RequestMapping(value="bookroom",method=RequestMethod.POST)
	public ModelAndView SelectRoom(Model m ,@ModelAttribute("idObj") RoomBean roombeanobj)
	{
		int id =  roombeanobj.getHotelid();
		ModelAndView mv=new ModelAndView();
		ArrayList<RoomBean> roomlist=hserv.selectroom(id);
		mv.setViewName("user/searchroom");
		mv.addObject("data", roomlist);
		return mv;
	}
	
	@RequestMapping(value="booking",method = RequestMethod.GET)								
	public String bookingroom(Model m,@RequestParam("hotelId") int hotelId,@RequestParam("roomId") int roomId , @RequestParam("perNight") int perNight )
	{
		m.addAttribute("hotelId", hotelId);
		m.addAttribute("roomId",roomId);
		m.addAttribute("perNight", perNight);
		BookingDetailsBean  bookbeanobj = new BookingDetailsBean();
		m.addAttribute("bookObj", bookbeanobj);
		return "user/bookingdetails";
	}

	@RequestMapping(value="amountcal",method = RequestMethod.POST)								
	public String booking(Model m,@ModelAttribute("bookObj")  BookingDetailsBean  bookbeanobj ,
			@RequestParam("hotelId") int hotelId,
			@RequestParam("roomId") int roomId , @RequestParam("perNight") int perNight)
	{
		//int amount=null;//this is causing null pointer exception
		
		BookingDetailsBean bean=new BookingDetailsBean();
	/*	SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
		java.util.Date d1=null;
		java.util.Date d2=null;
		try{
			d1=format.parse(bookbeanobj.getBookedFrom());
			d2=format.parse(bookbeanobj.getBookedTo());
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		int diff=(int) (d2.getTime()-d1.getTime());
		int diffDays=diff/(60*60*1000*24);
		System.out.println(diffDays);
		bean.setAmount((diffDays)*bookbeanobj.getNumberOfAdults()*perNight);
		System.out.println("amount to be paid:"+bookbeanobj.getAmount());
	*/	//int bookingid=hserv.BookRoom( hotelId,perNight,roomId,bookbeanobj.getBookedTo(),bookbeanobj.getBookedFrom(),bookbeanobj.getNumberOfAdults());
		/*m.addAttribute("hotelId", hotelId);
		m.addAttribute("roomId",roomId);
		m.addAttribute("perNight", roomId);*/
		bookbeanobj.setHotelid(hotelId);
		bookbeanobj.setRoomId(roomId);
		m.addAttribute("invoice",hserv.bookHotel(bookbeanobj, perNight));
		
		
		System.out.println(bookbeanobj);
		
		return "user/bookingsuccess";
	}
	/*********************************************************************************************************************************************
	 *                                                          EMPLOYEE LOGIN                                                                   *
	 *********************************************************************************************************************************************/
	@RequestMapping(value="emp",method = RequestMethod.POST)
	public String emp(Model m)
	{
		return "employee/employeelogin";
	}



	@RequestMapping(value="empForm",method = RequestMethod.POST)
	public String submit1(Model model, @ModelAttribute("empBean") EmployeeBean empBean)
	{
		if (empBean != null && empBean.getUserName() != null & empBean.getPassword() != null)
		{
			if (empBean.getUserName().equals("emp") && empBean.getPassword().equals("emp")) 
			{
				model.addAttribute("msg", empBean.getUserName());
				return "user/usermainscreen";
			} else {
				model.addAttribute("error", "Invalid Details");
				return "employee/employeelogin";
			}
		} else {
			model.addAttribute("error", "Please enter Details");
			return "employee/employeelogin";
		}
	}	
	

}















