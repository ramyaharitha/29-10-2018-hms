package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelService {

	
	public int addUserDetails(UserBean u);
	
	public int addHotelServ(HotelBean hotelbean);

	int addRoomServ(RoomBean roombean);

	public ArrayList<HotelBean> getAllHotels();

	public int deleteHotelById(int deletehotelid);
	
	boolean login(String userName, String password, UserBean userbean);

	public int deleteroomById(int deleteroomid);

	 public ArrayList<HotelBean> selecthotel(String location);

	public ArrayList<RoomBean> selectroom(int id);

	public BookingDetailsBean bookHotel(BookingDetailsBean bookBean, int perNight);
	public void updateHotelDetails(HotelBean hotelBean);
	ArrayList<HotelBean> searchHotelById(int id);
	
	
	
		public void updateRoomDetails(RoomBean roomBean);
		
		ArrayList<RoomBean> searchRoomById(int id);

		public ArrayList<BookingDetailsBean> viewBookingDetails(int hotel);

		public ArrayList<BookingDetailsBean> viewBookingByDate(String bookdate);

		public ArrayList<UserBean> viewGuestList(int hotelid);

		/*public int StoreBookingDetails(BookingDetailsBean bookbeanobj);
*/
	

}
